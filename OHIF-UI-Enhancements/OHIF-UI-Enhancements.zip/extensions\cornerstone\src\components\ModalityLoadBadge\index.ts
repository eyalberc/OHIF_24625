export { default } from './ModalityLoadBadge';
